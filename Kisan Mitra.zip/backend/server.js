require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

app.get('/api/location/reverse', async (req, res) => {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'Latitude and longitude are required.' });
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`, { headers: { 'User-Agent': 'KisanMitra/1.0' } });
        if (!response.ok) throw new Error('Reverse geocoding failed.');
        res.json(await response.json());
    } catch (error) {
        console.error(error);
        res.status(502).json({ error: 'Could not determine location.' });
    }
});

app.get('/api/weather', async (req, res) => {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'Latitude and longitude are required.' });
    if (!OPENWEATHER_API_KEY) return res.status(500).json({ error: 'Weather API key is not configured.' });
    try {
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&appid=${encodeURIComponent(OPENWEATHER_API_KEY)}&units=metric`;
        const response = await fetch(url);
        if (!response.ok) throw new Error('Weather API request failed.');
        res.json(await response.json());
    } catch (error) {
        console.error(error);
        res.status(502).json({ error: 'Weather data is not available.' });
    }
});

app.get('/api/market-prices', (req, res) => {
    const prices = { Wheat: 2250, Rice: 2800, Cotton: 6500, Potato: 1400, Onion: 1650, Soybean: 3800 };
    const cropName = String(req.query.crop || '');
    const crop = Object.keys(prices).find(name => name.toLowerCase() === cropName.toLowerCase());
    if (!crop) return res.json({ valid: false });
    res.json({ valid: true, crop, price: prices[crop] });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html')));

app.listen(PORT, () => console.log(`Kisan Mitra running at http://localhost:${PORT}`));
